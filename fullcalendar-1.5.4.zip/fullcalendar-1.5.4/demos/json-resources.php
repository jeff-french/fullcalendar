<?php

	echo json_encode(array(
	
		array(
			'id' => 1,
			'name' => "JSON Resource 1"
		),
		
		array(
			'id' => 2,
			'name' => "JSON Resource 2"
		),

        array(
			'id' => 3,
			'name' => "JSON Resource 3"
		)

	));

?>
